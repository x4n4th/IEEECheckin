/****************************************************************************
** Resource object code
**
** Created: Mon Apr 30 00:29:06 2012
**      by: The Resource Compiler for Qt version 4.7.1
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <QtCore/qglobal.h>

QT_BEGIN_NAMESPACE

QT_END_NAMESPACE


int QT_MANGLE_NAMESPACE(qInitResources_ieeecheckingui2)()
{
    return 1;
}

Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_ieeecheckingui2))

int QT_MANGLE_NAMESPACE(qCleanupResources_ieeecheckingui2)()
{
    return 1;
}

Q_DESTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qCleanupResources_ieeecheckingui2))

