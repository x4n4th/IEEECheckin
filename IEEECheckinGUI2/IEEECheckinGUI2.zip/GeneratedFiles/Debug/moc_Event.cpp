/****************************************************************************
** Meta object code from reading C++ file 'Event.h'
**
** Created: Mon Apr 30 20:47:37 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../../../documents/visual studio 2010/Projects/IEEECheckinGUI2/IEEECheckinGUI2/Event.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Event.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Event[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       7,    6,    6,    6, 0x0a,
      14,    6,    6,    6, 0x0a,
      24,    6,    6,    6, 0x0a,
      37,    6,    6,    6, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Event[] = {
    "Event\0\0Exit()\0UserAdd()\0SwipeEvent()\0"
    "ColorChangeOnSwipe()\0"
};

const QMetaObject Event::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Event,
      qt_meta_data_Event, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Event::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Event::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Event::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Event))
        return static_cast<void*>(const_cast< Event*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Event::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: Exit(); break;
        case 1: UserAdd(); break;
        case 2: SwipeEvent(); break;
        case 3: ColorChangeOnSwipe(); break;
        default: ;
        }
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
