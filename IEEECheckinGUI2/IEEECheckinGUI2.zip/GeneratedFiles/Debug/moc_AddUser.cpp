/****************************************************************************
** Meta object code from reading C++ file 'AddUser.h'
**
** Created: Mon Apr 30 17:08:43 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../AddUser.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AddUser.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AddUser[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x0a,
      18,    8,    8,    8, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_AddUser[] = {
    "AddUser\0\0Insert()\0Exit()\0"
};

const QMetaObject AddUser::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_AddUser,
      qt_meta_data_AddUser, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AddUser::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AddUser::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AddUser::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AddUser))
        return static_cast<void*>(const_cast< AddUser*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int AddUser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: Insert(); break;
        case 1: Exit(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
